#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "inventory.h"

void printinv(int fuel,int coins,int level,int goal,int map,int shield){
    printf("Level %d\n", level);
    printf("Inventory:\n");
    printf("Fuel Cans: %d\n", fuel);
    printf("Coins: %d\n", coins);
    printf("Pieces of Map: %d\n", map);
    printf("Shields: %d\n", shield);
    switch(goal){
        case 1:
            printf("Goal: Explore the planet\n");
            break;
        case 2:
            printf("Goal: Fly to the next planet\n");
            break;
        case 3:
            printf("Goal: Locate Bonzo\n");
            break;
        case 4:
            printf("Goal: Defeat Bonzo\n");
            break;
    }
}