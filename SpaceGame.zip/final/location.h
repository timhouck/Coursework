void printloc1(int loc);

void printloc2(int loc);