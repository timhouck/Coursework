#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "inventory.h"
#include "location.h"
    
int main(void){
    int choice=0,goal=1,loc=0,game=1;
    int fuel= 0,coins=0,level=1,cave=0,tower=0,map=0,shield=0;
    char name[50];
    while (game == 1){ //starts while loop
        while(loc==0){
            printf("\n~~~~~~~~~~~~~~\n");
            printf("SPACE DEFENDER\n");
            printf("~~~~~~~~~~~~~~\n");
            printf("\nEnter your name:");
            scanf("%s", name);
            printf("%s, you have been recruited to go on a top secret mission to a galaxy that poses a grave threat to Earth! You must find the location of the evil leader Bonzo on the planet Drago and save the world!\n", name);
            printf("You realize you only have enough fuel to get to one planet. Choose which planet you want to land on first\n");
            printf("1: Caprica\n");
            printf("2: Neveah\n");
            scanf("%d", &choice);
            switch(choice){
                case 1:
                    loc=1;
                    break;
                case 2:
                    loc=2;
                    break;
                default:
                    printf("Please enter 1 or 2.\n\n");
                    break;
            }
        }
        //Caprica
        while(loc==1){
            printf("\n");
            printinv(fuel,coins,level,goal,map,shield);
            printloc1(loc);
            printf("1: Rocket Ship\n");
            printf("2: Alien\n");
            printf("3: Cave\n");
            scanf("%d", &choice);
            switch(choice){
                case 1:
                    //Rocket ship
                    if(fuel>=1)
                        loc=3;
                    else
                        printf("You don't have enough fuel to go anywhere\n");
                    break;
                case 2:
                    //Alien
                    if(coins>=1){
                        printf("The alien offers you a canister of fuel for 1 coin\n");
                        printf("1: Buy fuel\n");
                        printf("2: Go back\n");
                        scanf("%d", &choice);
                        switch(choice){
                            case 1:
                                coins -= 1;
                                fuel += 1;
                                break;
                            case 2:
                                break;
                            default:
                                printf("Please enter 1 or 2.\n");
                                break;
                        }
                    }
                     else
                         printf("The alien tells you to come back when you have more coins\n");
                    break;
                case 3:
                    //Cave
                    if(cave==0){
                        //Continent Game
                        printf("You walk into the cave and see another earthling. You tell him about your mission. He tells you he was the first earthling tasked to defeat Bonzo. Bonzo got the best of him in their battle and forced him into hiding in this cave. He holds up a piece of a map to Bonzo and a coin and tells you they're yours if you can prove your smarts.\n");
                        printf("\"How many continents are there back on Earth?\" he asks\n");
                        printf("Answer:");
                        scanf("%d", &choice);
                        if(choice==7){
                            printf("\nCorrect! Use these wisely, you are Earth's only hope!\n");
                            coins += 1;
                            map +=1;
                            cave = 1;
                            goal = 2;
                        }
                        else
                            printf("\nNope! How are you supposed to save Earth if you don't even know that!?\n");
                    }
                    else
                        printf("You've already explored the cave.\n");
                    break;
                //Bad input
                default:
                    printf("Please enter 1, 2, or 3.\n");
                    break;
            }
        }
        //Neveah
        while(loc==2){
            printf("\n");
            printinv(fuel,coins,level,goal,map,shield);
            printloc1(loc);
            printf("1: Rocket Ship\n");
            printf("2: Shack\n");
            printf("3: Tower\n");
            scanf("%d", &choice);
            switch(choice){
                case 1:
                    //Rocket ship
                    if(fuel>=1)
                        loc=3;
                    else
                        printf("You don't have enough fuel to go anywhere\n");
                    break;
                case 2:
                    //Shack
                    if(coins>=1){
                        printf("You walk into the shack and see a tall, dark figure in a trench coat standing at a table. He offers you fuel for your ship for 2 coins.\n");
                        printf("1: Buy fuel\n");
                        printf("2: Go back\n");
                        scanf("%d", &choice);
                        switch(choice){
                            case 1:
                                coins -= 2;
                                fuel += 1;
                                break;
                            case 2:
                                break;
                            default:
                                printf("Please enter 1 or 2.\n");
                                break;
                        }
                    }
                     else
                         printf("You walk into the shack and see a tall, dark figure in a trench coat standing at a table. He tells you to get lost if you don't have any money.\n");
                    break;
                case 3:
                    //Tower
                    if(tower==0){
                        printf("You enter the tower and see stairs going all the way to the top. You walk up until you finally reach the top. There you find a table with a die and writing on it.\n");
                        //Higher or lower game
                        printf("It reads:\"Roll this die here. Predict whether the second roll will be higher or lower than the first.\"\n");
                       //Random number gen.
                        srand(time(NULL));
                        //First number will not be 1 or 6 to add difficulty
                        int num1=(rand()%4)+2;
                        printf("You roll the die. The first number is a %d\n",num1);
                        int num2=(rand()%6)+1;
                        while(num2==num1){
                            num2=(rand()%6)+1;
                        }
                        printf("Will the next number be higher or lower?\n");
                        printf("1: Higher\n");
                        printf("2: Lower\n");
                        scanf("%d", &choice);
                        printf("\nThe second number is a %d\n",num2);
                        switch(choice){
                            case 1:
                                if(num2>num1){
                                    printf("You were right! The table opens up and you find a piece of a map and 2 coins inside!\n");
                                    coins +=2;
                                    map +=1;
                                    tower =1;
                                    goal =2;
                                }
                                else
                                    printf("You got it wrong. Try again.\n");
                                break;
                            case 2:
                                if(num2<num1){
                                    printf("You were right! The table opens up and you find a piece of a map and 2 coins inside!\n");
                                    coins +=2;
                                    map +=1;
                                    tower =1;
                                    goal =2;
                                }
                                else
                                    printf("You got it wrong. Try again.\n");
                                break;
                            default:
                                 printf("Please enter 1 or 2.\n");
                                break;
                        }
                    }
                    else
                        printf("You've already explored the tower.\n");
                    break;
                //Bad input
                default:
                    printf("Please enter 1, 2, or 3.\n");
                    break;
            }
        }
        //Rocket Ship
         while(loc==3){
            printf("\n");
            printinv(fuel,coins,level,goal,map,shield);
            printloc2(loc);
            printf("1: Caprica\n");
            printf("2: Neveah\n");
            printf("3: Drago\n");
            scanf("%d", &choice);
            switch(choice){
                case 1:
                    //To Caprica
                    if(cave==1)
                        printf("You've already explored Caprica.\n");
                    else{
                        level+=1;
                        fuel-=1;
                        goal=1;
                        loc=1;
                    }
                    break;
                case 2:
                    //To Neveah
                    if(tower==1)
                        printf("You've already explored Neveah.\n");
                    else{
                        level+=1;
                        fuel-=1;
                        goal=1;
                        loc=2;
                    }
                    break;
                case 3:
                    //To Drago
                    if(map==2){
                        level+= 1;
                        fuel-=1;
                        loc=4;
                    }
                    else
                        printf("You need another piece of the map.\n");
                    break;   
                default:
                    printf("Please enter 1, 2, or 3.\n");
                    break;
            }
        }
        //Drago
        while(loc==4){
            printf("\n");
            goal=3;
            printinv(fuel,coins,level,goal,map,shield);
            printloc1(loc);
            printf("In front of you are 2 doors. Which one do you go through?\n");
            printf("1: Left\n");
            printf("2: Right\n");
            scanf("%d", &choice);
            //Ogre/Fairy Game
            switch(choice){
                case 1:
                    printf("There is a giant ogre in the middle of the room. He takes a huge club in his right hand and swings it at you!\n");
                    printf("1: Dodge backwards\n");
                    printf("2: Try to shoot your blaster\n");
                    printf("3: Charge him\n");
                    scanf("%d", &choice);
                    switch(choice){
                        case 1:
                            printf("You leap backwards right as the club blows by. You then quickly fire your blaster and knock the ogre dead! You manage to rip out one of his huge toenails and use it as a shield.\n");
                            shield=1;
                            level+=1;
                            loc=5;
                            break;
                        case 2:
                            printf("You are hit and killed with the club before you can fire your blaster.\n");
                            break;
                        case 3:
                            printf("As you charge the ogre he lifts his giant foot and crushes you under him.\n");
                            break;
                        default:
                            printf("Please enter 1, 2, or 3.\n");
                            break;
                    }
                    break;
                case 2:
                    printf("There is a giant fairy in the middle of the room. She looks harmless, but you never know...\n");
                    printf("1: Walk past her\n");
                    printf("2: Shoot your blaster at her\n");
                    printf("3: Let her make the first move\n");
                    scanf("%d", &choice);
                    switch(choice){
                        case 1:
                            printf("As you try to walk past her she hits you with a blast of magic, leaving you dead.\n");
                            break;
                        case 2:
                            printf("As you pull out your blaster, she's one step ahead of you and kills you with a blast of magic.\n");
                            break;
                        case 3:
                            printf("You take a cautious step and see the fairy fire a blast of magic at you. You see it just in time to dodge it and fire back a shot from your blaster, killing the evil fairy! You manage to rip one of her wings off and use it as a shield.\n");
                            shield=1;
                            level+=1;
                            loc=5;
                            break;
                        default:
                            printf("Please enter 1, 2, or 3.\n");
                            break;
                    }
                    break;
                default:
                    printf("Please enter 1 or 2.\n");
                    break;
            }
        }
        //Bonzo's Lair
        while(loc==5){
            printf("\n");
            shield=1;
            goal=4;
            printinv(fuel,coins,level,goal,map,shield);
            printloc2(loc);
            printf("\"Well if it isn't %s, the puny little earthling who thinks they can stop me from conquering his planet!\" he roars. \"If you want to stop me you'll have to do it right here!\"\n", name);
            //Bonzo game
            printf("Bonzo gets out of his throne and towers over you. He grabs his staff and swings it at you!\n");
            printf("1: Duck\n");
            printf("2: Block with your shield\n");
            printf("3: Shoot your blaster at him\n");
            scanf("%d",&choice);
            if(choice==1||choice==2){
                if(choice==1)
                    printf("You duck right as his staff swings over your head!\n");
                else{
                    printf("You throw your shield up and block the impact of the staff, but your shield breaks.\n");
                   shield-=1;
                }
                //Bonzo game pt. 2
                printf("\n");
                printinv(fuel,coins,level,goal,map,shield);
                printf("Bonzo immediatelly charges at you. You have no choice but to try to block the blow.\n");
                printf("1: Block with your shield\n");
                scanf("%d", &choice);
                if(choice==1){
                    if(shield>0){
                       loc=6;
                    }
                    else
                        printf("You try to pick up your broken shield, but Bonzo breaks straight through, delivering the fatal blow.\n");
                }
                else
                    printf("Please enter 1.\n");
            }
            else
                printf("You are struck down with the staff as you grab your blaster. As you lay on the floor Bonzo finishes you off.\n");   
        }
        while(loc==6){
            //Game End
            printf("\nBonzo runs straight into your shield, stunning him and causing him to drop his staff! You grab the staff off the floor and put it straight through his chest!\n\n");
            printf("You did it! You saved Earth!\n");
            printf("1: Play Again\n");
            printf("2: End Game\n");
            scanf("%d",&choice);
            switch(choice){
                case 1:
                    choice=0,goal=1,game=1,fuel= 0,coins=0,level=1,cave=0,tower=0,map=0,shield=0,loc=0;
                    break;
                case 2:
                    return 0;
                    break;
                default:
                    printf("Please enter 1 or 2.\n");
            }
        }
    }
}