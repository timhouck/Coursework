#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "location.h"

void printloc1(int loc){
    char locname[30];
    char locsee[200];
    switch(loc){
        case 1:
            strcpy(locname,"Caprica");
            strcpy(locsee,"You see your rocket ship, a strage alien, and a dark cave.");
            break;
        case 2:
            strcpy(locname,"Neveah");
            strcpy(locsee,"You see your rocket ship, a shack, and a tall tower.");
            break;
        case 4:
            strcpy(locname,"Drago");
            strcpy(locsee,"You piece your map together and follow it to Bonzo's Lair. In front of you are 2 doors.");
            break;
    }
    printf("You are on the planet %s. %s Where do you want to go?\n", locname, locsee); 
}

void printloc2(int loc){
    char locname[30];
    char locsee[200];
    switch(loc){
        case 3:
            strcpy(locname,"your rocket ship");
            strcpy(locsee,"Which planet do you want to go to?");
            break;
        case 5:
            strcpy(locname,"Bonzo's Lair");
            strcpy(locsee,"You see Bonzo sitting on his throne on the other side of the room. You walk towards him slowly.");
    }
    printf("You are in %s. %s\n", locname, locsee); 
}