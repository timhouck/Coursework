#include <iostream>
#include <string>

#include "taxinfo.hpp"

using namespace std;

int main(int argc, char *argv[]) {

    if (argc < 3){
        cout << "missing command line arguments" << endl;
        return -1;
    }

    /* TODO 2: Collect salary "inSalary" and tax rate "inTaxRate" from command line arguments
    *float inSalary = ...
    *float inTaxRate = ...
    */

    string SalaryStr = argv[1];
    string TaxRateStr = argv[2];
    float inSalary = stof(SalaryStr);
    float inTaxRate = stof(TaxRateStr);

    /* TODO 3: Assign data to TaxInfo variable
    *TaxInfo taxCalc;
    * ...
    */

    TaxInfo taxCalc;
    TaxInfo *p;
    taxCalc.salary = inSalary;
    taxCalc.taxRate = inTaxRate;

    /* TODO 4: Compute Tax using only pointer access
    * ...
    */

    p = &taxCalc;
    float OutTax = (p->salary)/(p->taxRate);

    /* TODO 5: Print salary, tax rate, and tax.
    * ...
    */
   
    cout << "Salary: " << p->salary << endl;
    cout << "Tax Rate: " << p->taxRate << endl;
    cout << "Incurred Tax: " << OutTax << endl;
 
   return 0;
}
