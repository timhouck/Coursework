#include "ShowCatalog.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

/* Completed functions. DO NOT MODIFY*/
ShowCatalog::ShowCatalog()
{
    root = nullptr;
}

/* Completed functions. DO NOT MODIFY*/
void destroyNode(ShowItem *current)
{
    if (current != nullptr)
    {
        destroyNode(current->left);
        destroyNode(current->right);

        delete current;
        current = nullptr;
    }
}

/* Completed functions. DO NOT MODIFY*/
ShowCatalog::~ShowCatalog()
{
    destroyNode(root);
}

/* Completed functions. DO NOT MODIFY*/
void printShowHelper(ShowItem *m)
{
    if (m != nullptr)
    {
        cout << "Show: " << m->title << " " << m->userRating << endl;
        printShowHelper(m->left);
        printShowHelper(m->right);
    }
}

/* Completed functions. DO NOT MODIFY*/
void ShowCatalog::printShowCatalog()
{
    if (root == nullptr)
    {
        cout << "Tree is Empty. Cannot print" << endl;
        return;
    }
    printShowHelper(root);
}

/* Completed functions. DO NOT MODIFY*/
ShowItem *getShowHelper(ShowItem *current, string title)
{
    if (current == NULL)
        return NULL;

    if (current->title == title)
        return current;

    if (current->title > title)
        return getShowHelper(current->left, title);

    return getShowHelper(current->right, title);
}

/* Completed functions. DO NOT MODIFY*/
void ShowCatalog::getShow(string title)
{
    ShowItem *node = getShowHelper(root, title);
    if (node != nullptr)
    {
        cout << "Show Info:" << endl;
        cout << "==================" << endl;
        cout << "Title :" << node->title << endl;
        cout << "Year :" << node->year << endl;
        cout << "Show Rating :" << node->showRating << endl;
        cout << "User Rating :" << node->userRating << endl;
        return;
    }

    cout << "Show not found." << endl;
}

/* Completed functions. DO NOT MODIFY*/
ShowItem *addNodeHelper(ShowItem *current, ShowItem *newNode)
{
    if (current == nullptr)
    {
        return newNode;
    }

    if (current->title > newNode->title)
    {
        current->left = addNodeHelper(current->left, newNode);
    }
    else
    {
        current->right = addNodeHelper(current->right, newNode);
    }

    return current;
}

/* Completed functions. DO NOT MODIFY*/
void ShowCatalog::addShowItem(string title, int year, string showRating, float userRating)
{
    if (root == nullptr)
    {
        root = new ShowItem(title, year, showRating, userRating);
        return;
    }

    root = addNodeHelper(root, new ShowItem(title, year, showRating, userRating));
}

/* TODO */
ShowItem* minValueNode(ShowItem* node)
{
    ShowItem* current = node;
  
    /* loop down to find the leftmost leaf */
    while (current && current->left != NULL)
        current = current->left;
  
    return current;
}

ShowItem* deleteNodeHelper(ShowItem* currNode, string data)
{
    // HINT: You might have to use the minValueNode function for one of the cases.
    if(currNode == NULL)
        return NULL;
    else if(currNode->title > data)
        currNode->left = deleteNodeHelper(currNode->left, data);
    else if(currNode->title < data)
        currNode->right = deleteNodeHelper(currNode->right, data);
    else{
        // Case 1 (no children)
        if(currNode->left == NULL && currNode->right == NULL){
            delete currNode;
            return NULL;
        }
        // Case 2 (1 child)
        else if(currNode->left == NULL){
            delete currNode;
            return currNode->right;
        }else if(currNode->right == NULL){
            delete currNode;
            return currNode->left;
        }
        // Case 3 (2 children)
        else{
            ShowItem* temp = minValueNode(currNode->right);
            currNode->title = temp->title;
            currNode->year = temp->year;
            currNode->showRating = temp->showRating;
            currNode->userRating = temp->userRating;
            currNode->right = deleteNodeHelper(currNode->right, temp->title);
            return currNode;
        }
    }
    return currNode;
}

void ShowCatalog::removeShow(std::string title)
{
    // TODO
    root = deleteNodeHelper(root, title);
}

ShowItem* rotateHelper(ShowItem* current, string title){
    if (current->left == NULL && current->right == NULL)
        return NULL;

    if(current->left){
        if(current->left->title == title){
            return current;
        }
    }
    if(current->right){
        if(current->right->title == title){
            return current;
        }
    }
    if (title.compare(current->title) < 0)
        return rotateHelper(current->left, title);

    return rotateHelper(current->right, title);
}
/* TODO */
void ShowCatalog::rightRotate(std::string title)
{
    // TODO
    // if y is root
    if(root->title == title){
        ShowItem* y = root;
        if(root->left){     // x is not null
        ShowItem* x = root->left;
        if(root->left->right){ //xr is not null
            ShowItem* xr = root->left->right;
            root = root->left;
            root->right = y;
            y->left = xr;
        }
        else{
            root = x;
            y->left = NULL;
            x->right = y;
        }
        }
        return;
    }
    ShowItem* yp = rotateHelper(root, title);
    int left = 0;
    if(!yp){return;}
    if(yp->left){
    if(yp->left->title == title){ // y is left child of yp
        left = 1;
        ShowItem* y = yp->left;
        if(y->left){ // x is not null
            ShowItem* x = y->left;
            if(x->right){ // xr is not null
                ShowItem* xr = x->right;
                yp->left = x; // yp parent of x
                x->right = y; // x parent of y
                y->left = xr; // y parent of xr
            }else{ // xr is null
                yp->left = x; // yp parent of x
                y->left = NULL; // y has no left child
                x->right = y; // x parent of y
            }
        }
    }
    }
    if(yp->right && left == 0){
    //cout << "right" << endl;
    if(yp->right->title == title){ // y is right child of yp
        ShowItem* y = yp->right;
        if(y->left){ // x is not null
            ShowItem* x = y->left;
            if(x->right){ // xr is not null
                ShowItem* xr = x->right;
                yp->right = x; // yp parent of x
                x->right = y; // x parent of y
                y->left = xr; // y parent of xr
            }else{ // xr is null
                yp->right = x; // yp parent of x
                y->left = NULL;
                x->right = y; // x parent of y
            }
        }
    }
    }
}

/* TODO */
void ShowCatalog::leftRotate(std::string title)
{
    // if x is root
    if(root->title == title){
        ShowItem* x = root;
        if(root->right){
        ShowItem* y = root->right;
        if(root->right->left){
            ShowItem* yl = root->right->left;
            root = root->right;
            root->left = x;
            x->right = yl;
        }
        else{
            root = y;
            x->right = NULL;
            y->left = x;
        }
        }
        return;
    }
    ShowItem* xp = rotateHelper(root, title);
    if(!xp){return;}
    if(xp->left){
    if(xp->left->title == title){ // x is left child of xp
        ShowItem* x = xp->left;
        if(x->right){ // y is not null
            ShowItem* y = x->right;
            if(y->left){ // yl is not null
                ShowItem* yl = y->left;
                xp->left = y; // xp parent of y
                y->left = x; // y parent of x
                x->right = yl; // x parent of yl
            }else{ // yl is null
                xp->left = y; // xp parent of y
                x->right = NULL;
                y->left = x; // y parent of x
            }
        }
    }
    }
    else if(xp->right){
    if(xp->right->title == title){ // x is right child of xp
        ShowItem* x = xp->right;
        if(x->right != NULL){ // y is not null
            ShowItem* y = x->right;
            if(y->left != NULL){ // yl is not null
                ShowItem* yl = y->left;
                xp->right = y; // xp parent of y
                y->left = x; // y parent of x
                x->right = yl; // y parent of xr
            }else{ // xr is null
                xp->right = y; // xp parent of y
                y->left = x; // y parent of x
                x->right = NULL;
            }
        }
    }
    }
}
