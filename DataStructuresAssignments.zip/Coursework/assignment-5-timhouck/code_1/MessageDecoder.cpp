#include <iostream>
#include <cstdlib>
#include <iostream>
#include "MessageDecoder.hpp"

using namespace std;
# define SIZE 50

MessageDecoder::MessageDecoder()
{
	/*
    DO NOT MODIFY THIS
    This constructor is already complete. 
    */
	head = NULL;
}

MessageDecoder::~MessageDecoder()
{
	// TODO
    while (!isEmpty()){
		pop();
    }
	head = NULL;
}

bool MessageDecoder::isEmpty()
{
	/* finished. do not touch. */
    return (head == NULL);
}

void MessageDecoder::push(char ch)
{
	// TODO
	Parser *node = new Parser;
    node->ch = ch;
	// if list is empty
	if(isEmpty()){
        node->next = NULL;
		head = node;
    }
	else{
		node->next = head;
		head = node;
	}
}

void MessageDecoder::pop()
{   
	// TODO
	if(isEmpty()){
        cout << "Stack empty, cannot pop an item." << endl;
    }
	else{
		Parser* node = head;
		head = head->next;
		delete node;
	}
}

Parser* MessageDecoder::peek()
{
	// TODO
	if(isEmpty()){
        cout << "Stack empty, cannot pop an item." << endl;
		return nullptr;
    }else{
		return head;
	}
}

void MessageDecoder::evaluate(char str[])
{
	// TODO
	char newstr[100];
	char secret[100];
	int i = 0;
	int j = 0;
	int k = 0;
	bool decoding = false;
	// push message to LL
	while(str[i]!= '\0'){
		push(str[i]);
		i++;
	}
	// peek and pop each char
    while (!isEmpty()){
		Parser* peeked = peek();
		newstr[j] = peeked->ch;
		if(decoding){
			if(newstr[j] == '{'){
			    for(int l=0;l<k;l++){
					cout << secret[l];
				}
				return;
			}
			secret[k] = newstr[j];
			k++;
		}
		if(newstr[j] == '}'){
			decoding = true;
		}
		pop();
		j++;
    }
	cout << "No secret message" << endl;
}
