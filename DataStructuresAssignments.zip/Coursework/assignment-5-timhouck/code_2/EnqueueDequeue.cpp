#include "EnqueueDequeue.hpp"

#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

EnqueueDequeue::EnqueueDequeue(){
	/* Already implemented, don't change */
    queueFront = -1;
	queueEnd = -1;
}

bool EnqueueDequeue::isEmpty(){
	//TODO
	if (queueFront==-1 && queueEnd==-1){
		return true;
	}else
    return false;
}

bool EnqueueDequeue::isFull(){
	//TODO
	if(queueSize() == SIZE){
		return true;
	}else{
		return false;
	}
}

void EnqueueDequeue::enqueue(std::string show){
	//TODO
    if(!isFull()){
		if(isEmpty()){
			queueFront = 0;
		}
		queueEnd = (queueEnd+1)%SIZE;
		queue[queueEnd] = show;
	}else{
		cout << "Queue full, cannot add a new show" << endl;
	}
}


void EnqueueDequeue::dequeue(){
	//TODO
	if(queueSize() == 1){
		//reset list
		queueFront = -1;
		queueEnd = -1;
	}else if(!isEmpty()){
		queueFront = (queueFront+1)%SIZE;
	}else{
		cout << "Queue empty, cannot dequeue show" << endl;
	}
}


string EnqueueDequeue::peek(){
	//TODO
	if(isEmpty()){
		cout << "Queue empty, cannot peek" << endl;
		return "";
	}
	string peeked = queue[queueFront];
	return peeked;
}

int EnqueueDequeue::queueSize(){
    //TODO
	int qsize;
	if(isEmpty()){
		return 0;
	}else if(queueEnd >= queueFront){
		qsize = queueEnd - queueFront + 1;
	}
	else{
		qsize = SIZE - (queueFront - queueEnd - 1);
	}
    return qsize;
}