#include "../code_2/EnqueueDequeue.hpp"
#include <iostream>

using namespace std;

/*
 * Purpose: displays a menu with options
 * @param none
 * @return none
 */
void menu(){
	cout << "*----------------------------------------*" << endl;
	cout << "Choose an option:" << endl;
    cout << "1. Enqueue new shows (Add shows to the queue)" << endl;
	cout << "2. Dequeue (Retrieve shows from the queue)" << endl;
	cout << "3. Return the queue size and exit" << endl;
	cout << "*----------------------------------------*" << endl;
}

int main(int argc, char const *argv[])
{
    // DO NOT MODIFY THIS.
    if(argc > 0)
    {
        freopen(argv[1],"r",stdin);
    }
    
    /* TODO */
    EnqueueDequeue ed;
    bool run = true;
    int option;
    int num;
    string show;
    while(run){
        menu();
        cin >> option;
        // TODO
        switch (option){
            case 1: //Enqueue
                cout << "Enter the number of shows to be enqueued:" << endl;
                cin >> num;
                cin.ignore();
                for(int i = 0; i < num; i++){
                    //int size = ed.queueSize();
                    cout << "Show" << i + 1 << ":" << endl;
                    getline(cin, show);
                    ed.enqueue(show);
                    if(ed.isFull()){
                        i = num;
                    }
                }
                break;
            case 2: //Dequeue
                cout << "Enter the number of shows to be dequeued:" << endl;
                cin >> num;
                for(int i = 0; i < num; i++){
                    if(ed.isEmpty()){
                        break;
                    }
                    show = ed.peek();
                    ed.dequeue();
                    cout << "Retrieved: " << show << endl;
                }
                if(ed.isEmpty()){
                    cout << "No more shows to retrieve from queue" << endl;
                }
                break;
            case 3: //Return size
                num = ed.queueSize();
                cout << "Number of shows in the queue:" << num << endl;
                run = false;
                break;
            default:
                cout << "Enter a valid option (1 or 2 or 3)" << endl;
                menu();
                //cin >> option;
                break;
        }
    }
    return 0;
}