#include <iostream>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "../code_1/array_double.hpp"

using namespace std;

int main(int argc, char* argv[])
{
    // TODO
    if (argc < 4)
    {
        cout << "file name missing" << endl;
        return -1;
    }
    // collect and open file
    string fileName = argv[1];
    ifstream myfile;
    myfile.open(fileName);
    string excludedRating = argv[2];
    int N = stoi(argv[3]);
    
    int capacity = 10;
    movieRecord *movieRecords;
    movieRecords = new movieRecord[capacity];


    string movieName;
    string userRatingString;
    float userRating;
    string mpaRating;
    string line;
    int counter = 0;
    int doublecount = 0;
    if (myfile.is_open()) // check existance of the file
    {
        // get data
        while (getline(myfile,line)){
            stringstream newline(line);
            getline(newline, movieName, '\t');
            getline(newline, userRatingString, '\t');
            userRating = stof(userRatingString);
            getline(newline, mpaRating);
            // check to be included
            if(checkMovieToBeIncluded(mpaRating, excludedRating)){
                // double array
                if(counter == capacity){
                    doubleArray(movieRecords, capacity);
                    doublecount++;
		        }
                // check if movie is distinct
                bool distinct = true;
                for(int i = 0; i < counter; i++){
                    if(movieRecords[i].movieName == movieName){
                        movieRecords[i].movieCount++;
                        movieRecords[i].avgUserRating = (float)((movieRecords[i].movieCount-1)*movieRecords[i].avgUserRating + userRating)/movieRecords[i].movieCount;
                        distinct = false;
                    }
                }
                if(distinct){
                    movieRecords[counter].movieName = movieName;
                    movieRecords[counter].avgUserRating = userRating;
                    movieRecords[counter].movieCount = 1;
                    counter++;
                }
            }
        }
        sortArray(movieRecords, counter);
        cout << "Array doubled: " << doublecount << endl;
        cout << "Distinct # of movies except " << excludedRating << ": " << counter << endl;
        int totalMovies = getTotalMoviesCount(movieRecords, counter);
        cout << "Total # of movies excluding " << excludedRating << " ratings: " << totalMovies << endl;
        printTopNMovies(movieRecords, N);
    }
    else{
        cout << "Failed to open the file." << endl;
    }
    return 0;
}
