#include "array_double.hpp"

bool checkMovieToBeIncluded(string movieMpaRating, string mpaRatingToBeExcluded){
    // TODO
    if(movieMpaRating != mpaRatingToBeExcluded){
        return true;
    } else
    return false;
}

void doubleArray(movieRecord *&movieArray, int &arrCapacity)
{
    // TODO
    int newCapacity = arrCapacity * 2;
    movieRecord *newArray = new movieRecord[newCapacity];
    for(int i=0; i < arrCapacity; i++){
		newArray[i] = movieArray[i];
	} 
    delete [] movieArray;
    movieArray = newArray;
	arrCapacity = newCapacity;
}

int getTotalMoviesCount(movieRecord* distinctMovies, int length) {
    // TODO
    int total = 0;
    for(int i = 0; i < length; i++){
        total = total + distinctMovies[i].movieCount;
    }
    return total;
}

void sortArray(movieRecord* distinctMovies, int length) {
    // TODO
    for(int i = 0; i < length; i++){
        for(int j = i+1; j < length; j++){
            if(distinctMovies[i].avgUserRating < distinctMovies[j].avgUserRating){
                movieRecord swap = distinctMovies[i];
                distinctMovies[i] = distinctMovies[j];
                distinctMovies[j] = swap;
            }
            // sort alphabetically if equal ratings
            if(distinctMovies[i].avgUserRating == distinctMovies[j].avgUserRating){
                if((distinctMovies[i].movieName.compare(distinctMovies[j].movieName))>0){
                    movieRecord swap = distinctMovies[i];
                    distinctMovies[i] = distinctMovies[j];
                    distinctMovies[j] = swap;
                }
            }
        }
    }
}

void printTopNMovies(movieRecord* movieArray,int numberOfMovies)
{
    // TODO
    int Z = 3;
    cout << fixed << setprecision(Z);
    cout << "Movie Ratings" << endl << "---------------------------------------" << endl;
    for(int i = 0; i < numberOfMovies; i++){
        cout<<movieArray[i].avgUserRating<<" "<<movieArray[i].movieName<<endl;
    }
}



