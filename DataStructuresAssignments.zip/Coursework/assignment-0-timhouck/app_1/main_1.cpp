#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char* argv[]){
        cout << "i'm a computer\n";
    return 0;
}