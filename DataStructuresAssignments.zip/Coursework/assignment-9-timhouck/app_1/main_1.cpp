#include <iostream>
#include <vector>
#include "../code_1/Puzzle.hpp"
#include <string>
using namespace std;

int main(int argc, char** argv)
{
    // Puzzle p(4);
    // p.createDefaultPuzzle();
    // p.createPath(0,2);
    // p.createPath(1,1);
    // p.createPath(2,2);
    // p.findVertexNumFromPosition(2,-3);
    // p.printPuzzle();
    Puzzle p1(5);
    p1.createDefaultPuzzle();
    p1.createPath(0, 0);
    p1.createPath(0, 1); 
    p1.createPath(1, 1); 
    p1.createPath(0, 2); 
    p1.createPath(1, 3);
    p1.createPath(2, 2); 
    p1.createPath(3, 1); 
    p1.createPath(4, 1); 
    p1.createPath(4, 2);
    p1.createPath(4, 3);
    p1.createPath(4, 4);
    p1.printPuzzle();
    return 0;
}
