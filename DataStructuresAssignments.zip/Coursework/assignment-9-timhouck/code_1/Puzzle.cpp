#include "Puzzle.hpp"
#include <vector>
#include <stack>
#include <iostream>

using namespace std;

Puzzle::Puzzle(int n){
    this->n = n;
}

void Puzzle::addEdge(int v1, int v2){
    //TODO
    int size = vertices.size();
    for(int i = 0; i < size; i++){
        if(vertices[i]->vertexNum == v1){
            for(int j = 0; j < size; j++){
                if(vertices[j]->vertexNum == v2){
                    int size2 = vertices[i]->adj.size();
                    for(int k = 0; k < size2; k++){
                        if(vertices[i]->adj[k].v->vertexNum == v2){
                            return;
                        }
                    }
                    adjVertex av;
                    av.v = vertices[j];
                    vertices[i]->adj.push_back(av);
                    //another vertex for edge in other direction
                    adjVertex av2;
                    av2.v = vertices[i];
                    vertices[j]->adj.push_back(av2);
                }
            }
        }
    }
}

void Puzzle::addVertex(int num){
    //TODO
        vertex * v = new vertex;
        v->vertexNum = num;
        vertices.push_back(v);
}

void Puzzle::displayEdges(){
    //TODO
    int size = vertices.size();
    for(int i = 0; i < size; i++)
    {
        int size2 = vertices[i]->adj.size();
        cout << vertices[i]->vertexNum << " --> ";
        for(int j = 0; j < size2; j++){
            cout << vertices[i]->adj[j].v->vertexNum << " " ;
        }
        cout << endl;
    }
}

// Finds the vertex number from the position of the open path in the maze
int Puzzle::findVertexNumFromPosition(int x, int y){
    //TODO
    if(x <= n && y <= n && y >= 0 && x >= 0){
        return y + n*x;
    }
    return -1;
}

// Creates a default maze of all 1s of size n x n, except for positions (0,0) and (n-1, n-1)
void Puzzle::createDefaultPuzzle(){
    //TODO
    puzzle = new int *[n];
    for(int i = 0; i < n; i++){
        puzzle[i] = new int [n];
        for(int j = 0; j < n; j++){
            if((i == 0 && j == 0) || (i == n-1 && j == n-1)){
                puzzle[i][j] = 0;
            }else{
               puzzle[i][j] = 1;
            }
        }
    }
}

void Puzzle::createPath(int i, int j){
    //TODO
    if(i <= n && j <= n && i >= 0 && j >= 0){
        puzzle[i][j] = 0;
    }
}

void Puzzle::printPuzzle(){
    //TODO
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            cout << "| " << puzzle[i][j] << " ";
            if(j == n-1){
                cout << "|" <<endl;
            }
        }
    }
}

vector<int> Puzzle::findOpenAdjacentPaths(int x, int y){
    vector<int> neighbors; 
    for(int i = x-1; i <= x + 1; i++){
        if(i < 0 || i >= n){
            continue;
        }
        for(int j = y-1; j <= y+1; j++){
            if(j < 0 || j >= n){
                continue;
            }
            // if there is an open path at this adjacent position, add to adjArray
            if(!(i == x && j == y) && puzzle[i][j] == 0){
                neighbors.push_back(findVertexNumFromPosition(i, j));
            }
        }
    }
    return neighbors;
}

void Puzzle::convertPuzzleToAdjacencyListGraph(){
    //TODO
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            if(puzzle[i][j] == 0){
                int pos = findVertexNumFromPosition(i,j);
                addVertex(pos);
            }
        }
    }
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            if(puzzle[i][j] == 0){
                int pos = findVertexNumFromPosition(i,j);
                vector<int> paths = findOpenAdjacentPaths(i,j);
                int size2 = paths.size();
                for(int k = 0; k < size2; k++){
                    addEdge(pos, paths[k]);
                }
            }
        }
    }
}

void DFTraversal(vertex *y, int n, int &pathDone, vector<int> &path)
{
    if(pathDone == 0){
        cout << "Reached vertex: " << y->vertexNum << endl;
    if(y->vertexNum == (n*n-1)){
        pathDone = 1;
    }
    y->visited = true;
    path.push_back(y->vertexNum);

    int size = y->adj.size();
    for(int x = 0; x < size; x++)
    {
        // TODO
        if(y->adj[x].v->visited == false){
            DFTraversal(y->adj[x].v, n, pathDone , path);
            if(pathDone == 0){
                cout << "Backtracked to vertex: " << y->vertexNum << endl;
                path.erase(path.end()-1);
            }
        }    
    }
    }
    else return;
}

bool Puzzle::findPathThroughPuzzle(){
    //TODO
    cout << "Starting at vertex: 0" << endl;
    int done = 0;
    DFTraversal(vertices[0], n, done, path);
    return checkIfValidPath();
}

bool Puzzle::checkIfValidPath(){
    //TODO
    if(path[0] != 0){
        return false;
    }
    int size = path.size();
    if(path[size-1] != (n*n - 1)){
        return false;
    }

    for(int i = 1; i < size; i++){
        int size2 = vertices.size();
        for(int i = 0; i < size2; i++){
            if(vertices[i]->vertexNum == path[i-1]){
                int size3 = vertices[i]->adj.size();
                for(int k = 0; k < size3; k++){
                    if(vertices[i]->adj[k].v->vertexNum == path[i]){
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

Puzzle::~Puzzle(){
    if (n > 0){
        for(int i = 0; i < n; i++){
            delete[] puzzle[i];
        }
        delete[] puzzle;
    }
    for (unsigned int i = 0; i< vertices.size(); i++){
        delete vertices[i]; 
    }
}
