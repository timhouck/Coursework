#include "ShowCatalog.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

ShowItem* createHelper(string title, int year, string showRating, float userRating){
    ShowItem* newShow = new ShowItem(title, year, showRating, userRating);
    return newShow;
}

ShowCatalog::ShowCatalog() {
    // TODO
    root = NULL;
}

void destructorHelper(ShowItem* node){
    if(node){
        destructorHelper(node->left);
        destructorHelper(node->right);
        delete node;
    }
    return;
}

ShowCatalog::~ShowCatalog() {
    // TODO
    destructorHelper(root);
}

void printHelper(ShowItem* curr){
    if(curr){
        cout << "Show: " << curr->title << " " << curr->userRating << endl;
        printHelper(curr->left);
        printHelper(curr->right);
    }
}

void ShowCatalog::printShowCatalog() {
    // TODO
    if(root==NULL){
        cout << "Tree is Empty. Cannot print" << endl;
    }else
    printHelper(root);
}

ShowItem* getHelper(ShowItem* curr, string title){
    if(curr == NULL){
        return NULL;
    }
    if(curr->title == title){
        return curr;
    }
    if(title.compare(curr->title) < 0){ //greater than
        return getHelper(curr->left, title);
    }
    return getHelper(curr->right, title);
}

void ShowCatalog::getShow(string title) {
    // TODO
    ShowItem* node = getHelper(root, title);
    if(node == NULL){
        cout << "Show not found." << endl;
    }
    else{
        cout << "Show Info:" << endl;
        cout << "==================" << endl;
        cout << "Title :" << node->title << endl;
        cout << "Year :" << node->year << endl;
        cout << "Show Rating :" << node->showRating << endl;
        cout << "User Rating :" << node->userRating << endl;
    }
}

ShowItem* addHelper(ShowItem* curr, string title, int year, string showRating, float userRating){
    if(curr == NULL){
        return createHelper(title, year, showRating, userRating);
    }
    else if(title.compare(curr->title) > 0){
        curr->right = addHelper(curr->right, title, year, showRating, userRating);
    }
    else if(title.compare(curr->title) < 0){
        curr->left = addHelper(curr->left,title, year, showRating, userRating);
    }
    return curr;
}

void ShowCatalog::addShowItem(string title, int year, string showRating, float userRating) {
    // TODO
    if(root == NULL){
        root = createHelper(title, year, showRating, userRating);
    }
    root = addHelper(root, title, year, showRating, userRating);
}

void leafHelper(ShowItem* node){
     if(node){
        if(!(node->left)&&!(node->right)){ // if leaf node
            cout << node->title << endl;
        }
        else{
            leafHelper(node->left);
            leafHelper(node->right);
        }
    }
}

void ShowCatalog::printLeafNodes() {
    // TODO
    leafHelper(root);
}

void searchHelper(ShowItem* curr, char titleChar){
    if(curr == NULL){
        return;
    }
    char first = curr->title[0];
    if(first == titleChar){
        cout << curr->title << "(" << curr->year << ") " << curr->userRating << endl;
        searchHelper(curr->left, titleChar);
        searchHelper(curr->right, titleChar);
    }
    else if(titleChar > first){ 
        searchHelper(curr->right, titleChar);
    }else{
        searchHelper(curr->left, titleChar);
    }
}

void ShowCatalog::searchShows(char titleChar) {
    // TODO
    if(root == NULL){
        cout << "Tree is Empty. Cannot search Shows" << endl;
    }
    else{
        cout << "Shows that starts with " << titleChar << ":" << endl;
        searchHelper(root, titleChar);
    }
}

void ratingHelper(ShowItem* curr, int &count, string showRating){
    if(curr == NULL){
        return;
    }
    if(curr->showRating == showRating){
        count++;
    }
    ratingHelper(curr->right, count, showRating);
    ratingHelper(curr->left, count, showRating);
}

void ShowCatalog::displayNumShowRating(int &count, string showRating) {
    // TODO
    ratingHelper(root, count, showRating);
}
