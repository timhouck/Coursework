#include "Graph.hpp"
#include <vector>
#include <queue>
#include <iostream>

using namespace std;

void Graph::addVertex(string name){
    //TODO
    bool found = false;
    int size = vertices.size();
    for(int i = 0; i < size; i++){
        if(vertices[i]->name == name){
            found = true;
        }
    }
    if(found == false){
        vertex * v = new vertex;
        v->name = name;
        vertices.push_back(v);
    }
    
}

void Graph::addEdge(string v1, string v2){
    //TODO
    int size = vertices.size();
    for(int i = 0; i < size; i++){
        if(vertices[i]->name == v1){
            for(int j = 0; j < size; j++){
                if(vertices[j]->name == v2 && i != j){
                    adjVertex av;
                    av.v = vertices[j];
                    vertices[i]->adj.push_back(av);
                    //another vertex for edge in other direction
                    adjVertex av2;
                    av2.v = vertices[i];
                    vertices[j]->adj.push_back(av2);
                }
            }
        }
    }
}

void Graph::displayEdges(){
    //TODO
    int size = vertices.size();
    for(int i = 0; i < size; i++)
    {
        int size2 = vertices[i]->adj.size();
        cout << vertices[i]->name << " --> ";
        for(int j = 0; j < size2; j++){
            cout << vertices[i]->adj[j].v->name << " " ;
        }
        cout << endl;
    }
}

void Graph::breadthFirstTraverse(string sourceVertex){
    //TODO
    // for the source vertex in the graph
    vertex *vStart;
    int size = vertices.size();
    for(int i = 0; i < size; i++)
    {
        if(vertices[i]->name == sourceVertex)
        {
            vStart = vertices[i];
        }
    }

    cout<< "Starting vertex (root): " << vStart->name << "-> ";
    
    vStart->visited = true;

    // Use the queue to keep track of visited vertices
    queue<vertex*> q;

    // Enqueue the source vertex
    q.push(vStart);

    vertex *n;
   
    // standard BFS
    while(!q.empty()){

        n = q.front();
        q.pop();
        int size2 = n->adj.size();
        // go to all the adjacent vertices of n
        for( int x = 0; x < size2; x++ )
        {
            // If a adjacent has not been visited, then mark it visited and enqueue it
            // Update the distance of the adjacent vertices along the way
            // Stop when you reach the destination vertex and return the needful
            if(n->adj[x].v->visited == false){
                n->adj[x].v->visited = true;
                n->adj[x].v->distance = n->distance + 1;
                q.push(n->adj[x].v);
                // for other vertex traversed from source vertex with distance
                cout << n->adj[x].v->name <<"("<< n->adj[x].v->distance <<")"<< " ";
            }       
        }
    }
    cout << endl << endl;

}

/*
string::source : source vertex (starting city)
int::k : distance that you can travel from source city with remaining fuel
*/
vector<string> Graph::findReachableCitiesWithinDistanceK(string source, int k){
    //TODO
        vertex *vStart;
    int size = vertices.size();
    for(int i = 0; i < size; i++)
    {
        if(vertices[i]->name == source)
        {
            vStart = vertices[i];
        }
    }

    vStart->visited = true;

    // Use the queue to keep track of visited vertices
    queue<vertex*> q;

    // Enqueue the source vertex
    q.push(vStart);

    vertex *n;

    vector<string> list;
   
    // standard BFS
    while(!q.empty()){

        n = q.front();
        q.pop();
        int size2 = n->adj.size();
        // go to all the adjacent vertices of n
        for( int x = size2 - 1; x > -1; x-- )
        {
            // If a adjacent has not been visited, then mark it visited and enqueue it
            // Update the distance of the adjacent vertices along the way
            // Stop when you reach the destination vertex and return the needful
            if(n->adj[x].v->visited == false){
                n->adj[x].v->visited = true;
                n->adj[x].v->distance = n->distance + 1;
                q.push(n->adj[x].v);   
                if(n->adj[x].v->distance == k){
                   list.push_back(n->adj[x].v->name);
                } 
            }       
        }
    }
    return list;
}
