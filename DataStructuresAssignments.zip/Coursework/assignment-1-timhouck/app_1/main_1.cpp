#include <iostream>
#include <fstream>
#include "../code_1/fundamentals_1.hpp"

using namespace std;

int main(int argc, char* argv[]) {
    // TODO
    if (argc < 2)
    {
        cout << "file name missing" << endl;
        return -1;
    }
    // collect and open file
    string fileName = argv[1];
    ifstream myfile;
    myfile.open(fileName);

    float arr[100];
    int counter = 0;
    string line;
    if (myfile.is_open()) // check existance of the file
    {
        while (getline(myfile,line))
        {
            float newFloat = stof(line);
            counter = addToArrayAsc(arr, counter , newFloat);
            for(int i = 0; i < counter; i++){
                if(i == (counter -1)){
                    cout << arr[i] << endl;
                }else {
                    cout << arr[i] << ",";
                }
            }
        }
    }
    else{
        cout << "Failed to open the file." << endl;
    }
    return 0;
}