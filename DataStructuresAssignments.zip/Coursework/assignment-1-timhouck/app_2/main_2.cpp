#include <iostream>
#include <fstream>
#include "../code_2/fundamentals_2.hpp"
#include <sstream>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
    // TODO
    if (argc < 5)
    {
        cout << "file name missing" << endl;
        return -1;
    }
    // collect and open file
    string inFile = argv[1];
    string outFile = argv[2];
    double lowBound = stod(argv[3]);
    double highBound = stod(argv[4]);
    ifstream myfile;
    myfile.open(inFile);

    emissionInfo arr[119];
    string countryName; 
    double emission_in_2015;
    double emission_in_2016; 
    double emission_in_2017;
    double emission_in_2018;
    double emission_in_2019;
    string temp;

    int counter = 0;
    string line;
    if (myfile.is_open()) // check existance of the file
    {
        while (getline(myfile,line))
        {
            stringstream newline(line);
            getline(newline, countryName, ',');
            getline(newline, temp, ',');
            emission_in_2015 = stod(temp);
            getline(newline, temp, ',');
            emission_in_2016 = stod(temp);
            getline(newline, temp, ',');
            emission_in_2017 = stod(temp);
            getline(newline, temp, ',');
            emission_in_2018 = stod(temp);
            getline(newline, temp, ',');
            emission_in_2019 = stod(temp);
            insertEmissionInfo(arr, countryName, emission_in_2015, emission_in_2016, emission_in_2017, emission_in_2018, emission_in_2019, counter);
            counter ++;
        }
    }
    else{
        cout << "Failed to open the file." << endl;
    }

    // regular terminal output
    for (int i = 0; i < counter; i++)
    {
        if ((highBound >= arr[i].average)&&(arr[i].average >= lowBound)){
            cout << arr[i].countryName << "," << arr[i].average << "," << calcEmissionZone(arr[i].average) << endl;
        }
    }
    int x = 24;
    int *p = &x;
    int *p2;
    p2 = &x;
    int *p3 = p2;
    cout << *p << endl;
    cout << p << endl;
    cout << &p << endl;
    cout << *p2 << endl;
    cout << *p3 << endl;

    int a = 30;
    int b = 40;
    int c = 50;
    int *pa = &a;
    int *pb = &b;
    int *pc = &c;
    *pc = *pa + *pb;
    pb = pa;
    cout << *pa << endl;
    cout << *pb << endl;
    cout << *pc << endl;
    cout << a << endl;
    cout << b << endl;
    cout << c << endl;

    // file output
    ofstream oFile(outFile);
    for (int i = 0; i < counter; i++)
    {
        if ((highBound >= arr[i].average)&&(arr[i].average >= lowBound)){
            oFile << arr[i].countryName << "," << arr[i].average << "," << calcEmissionZone(arr[i].average) << endl;
        }
    }
    oFile.close();
    return 0;
}