#include "fundamentals_1.hpp"

int addToArrayAsc(float sortedArray[], int numElements, float newValue) {
    // TODO
    sortedArray[numElements] = newValue;
    numElements++;
    // sort array elements
    for(int i = 0; i < numElements; i++){
        for(int j = i+1; j < numElements; j++){
            if(sortedArray[i] > sortedArray[j]){
                float swap = sortedArray[i];
                sortedArray[i] = sortedArray[j];
                sortedArray[j] = swap;
            }
        }
    }
    return numElements;
}

