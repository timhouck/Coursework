#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include "../code_1/ShowsList.hpp"

using namespace std;

void displayMenu();

int main(int argc, char* argv[])
{

    // DO NOT MODIFY THIS.
    if(argc>1) 
    {
        freopen(argv[1],"r",stdin);
    }
    // DO NOT MODIFY ABOVE.
    ShowsList sl; 
    bool run = true;
    int option;
    double rating;
    string name;
    string prev;
    while(run)
    {
    displayMenu();
    cin >> option;
    // TODO
    switch (option)
    {
    case 1: // Build Schedule 
        sl.buildShowsList();
        sl.displayShows(); 
        break;
    case 2: // Display Shows
        sl.displayShows();
        break;
    case 3: // Add Show
        cout << "Enter a new show name: "<< endl;
        cin.ignore();
        getline(cin, name);
        cout << "Enter the previous show name (or First): " << endl;
        getline(cin, prev);
        if(prev != "First" && sl.searchShow(prev) == NULL){
            cout << "INVALID(previous show name)... Please enter a VALID previous show name!" << endl;
            getline(cin, prev);
        }
        if(prev == "First"){
            sl.addShow(NULL, name);
        }else{
        sl.addShow(sl.searchShow(prev), name);
        }
        if(prev != "First" && sl.searchShow(prev) == NULL){
            cout << "INVALID(previous show name)... Please enter a VALID previous show name!" << endl;
        }else{
            sl.displayShows();
            break;
        }
    case 4:
        cout << "Enter name of the show to add the rating: " << endl;
        cin.ignore();
        getline(cin, name);
        cout << "Enter the rating: "<< endl;
        cin >> rating;
        sl.addRating(name,rating);
        break;
    case 5:
        cout << "Quitting..." << endl;
        run = false;
        break;
    default:
        run = false;
        break;
    }
    }
    cout << "Goodbye!" << endl;
    return 0;
}




/************************************************
           Definitions for main_1.cpp
************************************************/
void displayMenu()
{
    // COMPLETE
    cout << "Select a numerical option:" << endl;
    cout << "+=====Main Menu=========+" << endl;
    cout << " 1. Build schedule " << endl;
    cout << " 2. Display Shows " << endl;
    cout << " 3. Add Show " << endl;
    cout << " 4. Add rating" << endl;
    cout << " 5. Quit " << endl;
    cout << "+-----------------------+" << endl;
    cout << "#> ";
}
