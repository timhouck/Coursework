/*************************************************************/
/*                   ShowsList Definition                    */
/*************************************************************/
/* TODO: Implement the member functions of class ShowsList   */
/*     This class uses a linked-list of Show structs to      */
/*     represent the schedule of shows                       */
/*************************************************************/

#include "ShowsList.hpp"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

/*
 * Purpose: Constructor for empty linked list
 * @param none
 * @return none
 */
ShowsList::ShowsList() {
    /*
    DO NOT MODIFY THIS
    This constructor is already complete. 
    */
    head = nullptr;
}

/*
 * Purpose: Check if list is empty
 * @return true if empty; else false
 */
bool ShowsList::isEmpty() {
    /* finished. do not touch. */
    return (head == NULL);
}

/*
 * Purpose: prints the current list of shows nicely
 * @param none
 * @return none
 */
void ShowsList::displayShows() {
    // TODO: Copy-paste your solution from Assignment 3
    Show* temp = head;
    //if list is empty
    if(isEmpty()){
        cout<< "nothing in path" << endl;
        return;
    }
        cout << "== CURRENT SHOWS LIST ==" << endl;
    // print shows
    while(temp->next != NULL){
        cout<< temp->name <<"-> ";
        temp = temp->next;
    }
    cout<<temp->name<<"-> ";
    cout<< "NULL" << endl;
    cout << "===" << endl;
}

/*
 * Purpose: Add a new show to the shows linked list
 *   between the previous and the show that follows it in the list.
 * @param previousShow the show that comes before the new show
 * @param showName name of the new Show
 * @return none
 */
void ShowsList::addShow(Show* previousShow, string showName) {
    // TODO: Copy-paste your solution from Assignment 3
    Show *node = new Show;
    node->name = showName;
    node->rating = 0;
    node->numberRatings = 0;

    //Check if head is Null i.e list is empty
    if(head == NULL){
        node->next = NULL;
        head = node;
        cout<< "adding: " << showName << " (HEAD)" << endl;
    }

    // if list is not empty, look for prev and append our node there
    else if(previousShow == NULL)
    {
        node->next = head;
        head = node;
        cout<< "adding: " << showName << " (HEAD)" << endl;
    }
    //general insertion
    else{
        Show *temp = previousShow->next;
        previousShow->next = node;
        node->next = temp;
        cout << "adding: " << showName << " (prev: " << previousShow->name << ")" << endl;
    }
}

/*
 * Purpose: populates the ShowsList with the predetermined shows
 * @param none
 * @return none
 */
void ShowsList::buildShowsList() {
    // TODO: Copy-paste your solution from Assignment 3
    Show* node = head;
    Show* next = NULL;
    while(node != NULL){
        next = node->next;
        free(node);
        node = next;
    }
    head = NULL;
    // "Friends", "Ozark", "Stranger Things", "The Boys", "Better Call Saul"
    addShow(NULL, "Friends");
    addShow(searchShow("Friends"), "Ozark");
    addShow(searchShow("Ozark"), "Stranger Things");
    addShow(searchShow("Stranger Things"), "The Boys");
    addShow(searchShow("The Boys"), "Better Call Saul");
}

/*
 * Purpose: Search the ShowsList for the specified show and return a pointer to that node
 * @param showName - name of the show to look for in list
 * @return pointer to node of show, or NULL if not found
 *
 */
Show* ShowsList::searchShow(string showName) {
    // TODO: Copy-paste your solution from Assignment 3
    Show* ptr = head;
    if(showName == "First"){
        return nullptr;
    }
    while(ptr != NULL){
      if(ptr->name == showName){
        return ptr;
      }
      ptr = ptr->next;
    }
    return nullptr;
}

/*
 * Purpose: Give a new rating to a show
 * @param receiver - name of the show that is receiving the rating
 * @param rating - the rating that is being given to a show
 * @return none
 */
void ShowsList::addRating(string receiver, double rating) {
    // TODO: Copy-paste your solution from Assignment 3
    if(isEmpty()){
        cout << "Empty list" << endl;
        return;
    }
    if(searchShow(receiver)==nullptr){
        cout << "Show not found" << endl;
        return;
    }
    Show* node = searchShow(receiver);
    node->numberRatings++;
    node->rating = (node->rating*(node->numberRatings-1) + rating)/node->numberRatings;
    cout << "The rating has been updated: " << node->rating << endl;    
}


/****************************************************/
/*  ASSIGNMENT 4: Functions to be completed below.  */
/****************************************************/


/*
 * Purpose: Delete the Show in the list with the specified name.
 * @param showName - name of the Show to delete in the list.
 * @return none
 */
void ShowsList::removeShows(string showName)
{
    //TODO: Complete this function
    if(head == NULL){
        cout << "Show does not exist." << endl;
        return;
    }
    // delete at head
    if (searchShow(showName) == head){
       //todo
       Show *temp = head;
       head = head->next;
       delete temp;
       return;
    }
    // delete elsewhere
    Show *pres = head;
	Show *prev = NULL;
    while(pres->name != showName){
        prev = pres;
        pres = pres->next;
        if(pres == NULL && prev->name != showName){
            cout << "Show does not exist." << endl;
            return;
        }
    }
    prev->next = pres->next;
    pres->next = NULL;
    delete pres;
}

/*
 * Purpose: deletes all Shows in the list starting from the head of the linked list.

 * @param: none
 * @return: none
 */
void ShowsList::purgeCompleteShowList()
{
    // TODO: Complete this function
    Show* node = head;
    Show* next = NULL;
    while(node != NULL){
        next = node->next;
        cout << "deleting: " << node->name << endl;
        free(node);
        node = next;
    }
    head = NULL;
    cout << "Deleted show list" << endl;
}

/*
* Purpose: Creates a loop from last node to the show name specified.
* @param showName - name of the show to loop back to
* returns the last node before loop creation (to break the loop)
*/
Show* ShowsList::produceGlitch(string showName) 
{
    /*
    DO NOT MODIFY THIS
    This function is already complete. 
    */
    Show* ptr = searchShow(showName);
    Show* temp = head;
    while(temp && temp->next!=NULL){
        temp=temp->next;
    }
    if(ptr && temp)
        temp->next=ptr;
    return temp;
}

/*
 * Purpose: to detect loop in the linked list
 * @return: true if loop is detected, else false
 */
bool ShowsList::findGlitch() 
{
    // TODO: Complete this function
    if(head == NULL){
        return false;
    }
    Show* fast = head->next;
    Show* slow = head;
    while(fast != NULL && fast->next != NULL && slow != NULL){
        if(fast == slow){
            return true;
        }
        fast = fast->next->next;
        slow = slow->next;
    }
    return false;
}

void ShowsList::rearrangeShowList(int start, int end)
{
    // TODO: Complete this function
    // check for errors
    if(start > end){
        cout << "Invalid indices" << endl;
        return;
    }
    if(end < 0){
        cout << "Invalid end index" << endl;
        return;
    }
    if(start < 0){
        cout << "Invlaid start index" << endl;
        return;
    }
    Show* startNode = head;
    // check if empty
    if(head == NULL){
        cout << "Linked List is Empty" << endl;
        return;
    }
    // find start node
    for(int i=0;i<start;i++){
      startNode = startNode->next;
      if(startNode == NULL){
        cout << "Invalid start index" << endl;
        return;
    }
    }
    // find end node
    Show* endNode = head;
    for(int i=0;i<end;i++){
      endNode = endNode->next;
      if(endNode->next == NULL){
        cout << "Invalid end index" << endl;
        return;
    }
    }
    Show* temp = head;
    // go to end of list
    while(temp->next != NULL){
        temp = temp->next;
    }
    temp->next = startNode; // last element now points to start node
    temp = head;
    // find node before start node
    if(start == 0){
        head = endNode->next;
    }else{
        while(temp->next != startNode){
            temp = temp->next;
        }
        temp->next = endNode->next;   // node before start now points to node after endNode
    }
    endNode->next = NULL;
}
