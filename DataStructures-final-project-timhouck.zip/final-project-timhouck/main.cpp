//-----------------------------------------------------------------------------
// CSCI2270 Course Project
//
// Identification: main.cpp
//-----------------------------------------------------------------------------

#include "HashOpenAddressing.h"
#include "HashChaining.h"

#include <iostream>
#include <sstream>
#include <string>

using namespace std;


/**
* main - main function displays menu and calls hashChaining and HashOpenAddressing 
* functions to populate and display information from hash tables
* 
* @param argc argv[]
* @return int
*/

int main (int argc, char* argv[])
{
   	// error if more than 3 comamnd line arguments
	if (argc != 3)
	{
		cout << "Invalid number of arguments." << endl;
        cout << "Usage: ./<program name> <csv file> <hashTable size>" << endl;
        return 1;
	}

	// construct hash tables of input size
    int size = stoi(argv[2]);
    HashOpenAddressing hoa(size);
    HashChaining hc(size);

    string fileName = argv[1];

    bool quit = false;
	while (!quit)
	{
		int option;
		string inputLine;

		// user interface
		cout << "======Main Menu======" << endl;
		cout << "1. Populate hash tables" << endl;
		cout << "2. Search for a course" << endl;
		cout << "3. Search for a professor" << endl;
        cout << "4. Display all courses" << endl;
		cout << "5. Exit" << endl;
        cout << "Enter an option: ";
		getline(cin, inputLine);
		cout << endl;
		option = stoi(inputLine);
		
		// error if invalid option
		if (option < 1 || option > 5){
			cout << "Invalid option : " << inputLine << endl;
		}

		switch (option)
		{
			case 1: // Populate hash tables
			{
                hoa.bulkInsert(fileName);
				hc.bulkInsert(fileName);
				break;
			}
			case 2: // Search for course
			{
				int year;
				int num;
				string id;
				string temp;
				cout << "Enter the course year (e.g. 2021): " << endl;
				getline(cin, temp);
				year = stoi(temp);
				cout << "Enter a course number (e.g. 2270): " << endl;
				getline(cin, temp);
				num = stoi(temp);
				cout << "Enter a Professor's ID (e.g. llytellf): " << endl;
				getline(cin, id);
				cout << endl;
				hoa.search(year, num, id);
				hc.search(year, num, id);
				break;
			}
			case 3: // Search for professor
			{
				string profId;
				cout << "Enter a Professor's ID (e.g. nscollan0):" << endl;
				getline(cin,profId);
				cout << "[OPEN ADDRESSING] Search for a professor" << endl << "----------------------------------------" << endl;
				hoa.profDb.publicSearchProfessor(profId);
				cout << "[CHAINING] Search for a professor" << endl << "----------------------------------------" << endl;
				hc.profDb.publicSearchProfessor(profId);
				break;
			}
            case 4: // Display all courses
            {
				cout << "Which hash table would you like to display the courses for? (O=Open Addressing, C=Chaining)"<<endl;
				getline(cin, inputLine);
				if(inputLine == "O"){
					hoa.displayAllCourses();
				}else if(inputLine == "C"){
					hc.displayAllCourses();
				}else{
					cout << "Please enter a valid input" << endl;
				}
				break;
            }
			case 5: // Exit
			{
				quit = true;
			}
		}
	}

	cout << "Goodbye!" << endl;

    return 0;
}