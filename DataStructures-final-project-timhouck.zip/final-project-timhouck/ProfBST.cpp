//-----------------------------------------------------------------------------
// CSCI2270 Course Project
//
// Identification: ProfBST.cpp
//-----------------------------------------------------------------------------

#include "ProfBST.h"

#include <iostream>

using namespace std;

/**
* ProfBST - constructor for ProfBST, sets root to null
* 
* @param -
* @return -
*/

ProfBST::ProfBST()
{
    root = NULL;
}

/**
* destructHelper - helper function that recursively deletes each professor node
* 
* @param curr
* @return -
*/

void destructHelper(Professor* curr){
    if(curr!=NULL){
        destructHelper(curr->left);
        destructHelper(curr->right);
        for(int i = 0; i < curr->coursesTaught.size(); i++){
            delete curr->coursesTaught[i];
        }
        delete curr;
        curr = NULL;
    }
}

/**
* ~ProfBST - denstructor for ProfBST, calls destructHelper starting at root
* 
* @param -
* @return -
*/

ProfBST::~ProfBST()
{
    destructHelper(root);
}

/**
* createHelper - helper function that creates new instance of professor
* 
* @param profId, profName
* @return Professor *
*/

Professor* createHelper(string profId, string profName)
{
    Professor* np = new Professor;
    np->profId = profId;
    np->profName = profName;
    return np;
}

/**
* addNodeHelper - helper function that finds correct place in BST and calls createHelper when found
* 
* @param currNode, profId, profName
* @return Professor *
*/

Professor* addNodeHelper(Professor* currNode, string profId, string profName)
{
    if(currNode == NULL){
        return createHelper(profId, profName);
    }
    else if(currNode->profId < profId){
        currNode->right = addNodeHelper(currNode->right,profId, profName);
    }
    else if(currNode->profId > profId){
        currNode->left = addNodeHelper(currNode->left,profId, profName);
    }
    return currNode;
}

/**
* addProfessor - calls addNodeHelper if professor is not already created
* 
* @param profId, profName
* @return -
*/

void ProfBST::addProfessor(string profId, string profName)
{
    // adds professor if professor does not already exist
    if(!searchProfessor(profId)){
        root = addNodeHelper(root, profId, profName);
        if(root->profId == profId){
            root->left = NULL;
            root->right = NULL;
        }
    }
}

/**
* searchHelper - helper function that recursively searches throught the BST until the input profId is matched
* 
* @param currNode, profId
* @return Professor *
*/

Professor* searchHelper(Professor* currNode, string profId){
    if(currNode == NULL)
        return NULL;

    if(currNode->profId == profId)
        return currNode;

    if(currNode->profId > profId)
        return searchHelper(currNode->left, profId);

    return searchHelper(currNode->right, profId);
}

/**
* searchProfessor - calls searchHelper and returns found node
* 
* @param profId
* @return Professor *
*/

Professor* ProfBST::searchProfessor(string profId)
{
    Professor* found = searchHelper(root,profId);
    return found;
}

/**
* publicSearchProfessor - calls searchHelper to find the professor and then calls displayProfessorInfo
* 
* @param profId
* @return -
*/

void ProfBST::publicSearchProfessor(string profId)
{
    Professor* found = searchHelper(root,profId);
    displayProfessorInfo(found);
}

/**
* displayProfessorInfo - displays the name of the professor and the info of each course taught for the input professor
* 
* @param p
* @return -
*/

void ProfBST::displayProfessorInfo(Professor* p)
{
    if(p){ // if professor is found
        cout << "Name: " << p->profName << endl;
        // loops through each course taught and displays course info
        for(int i = 0; i < p->coursesTaught.size(); i++){
            cout << "- " << p->coursesTaught[i]->courseNum <<": "<< p->coursesTaught[i]->courseName <<", "<<p->coursesTaught[i]->year << endl;
        }
        cout << endl;
    }
    else{
        cout << "Professor not found" << endl << endl;
    }
}
