//-----------------------------------------------------------------------------
// CSCI2270 Course Project
//
// Identification: HashChaining.cpp
//-----------------------------------------------------------------------------

#include "HashChaining.h"

using namespace std;

/**
* HashChaining - constructor for HashChaining
* 
* @param size
* @return -
*/

HashChaining::HashChaining(int size)
{
    hashTableSize = size;
    hashTable = new Course*[hashTableSize];
    for(int i=0;i<size;i++)
        hashTable[i] = nullptr;
}

/**
* ~HashChaining - destructor for HashChaining
* 
* @param -
* @return -
*/

HashChaining::~HashChaining()
{
    for(int i=0;i<hashTableSize;i++)
        hashTable[i] = nullptr;
    delete hashTable;
}

/**
* hash - calculates the hash of a key
* 
* @param courseNumber
* @return int
*/

int HashChaining::hash(int courseNumber)
{
    return courseNumber % hashTableSize;
}

/**
* bulkInsert - inserts all courses in a file to hash table using
* quadratic probing while adding each new professor to a BST 
*
* @param filename
* @return -
*/

void HashChaining::bulkInsert(string filename)
{
    int colCount = 0;
    int searchCount = 0;
    ifstream dataFile;
	string dataLine;
    dataFile.open(filename);
    getline(dataFile, dataLine); //discard example line
    profDb.~ProfBST();
    while (getline(dataFile, dataLine))
	{
        int year;
        string department;
        int courseNum;
        string courseName;
        string profID;
        string profFirst;
        string profLast;
        string temp;

		stringstream dataStream(dataLine);

        // year
		getline(dataStream, temp, ',');
        year = stoi(temp);
        // department
		getline(dataStream, department, ',');
		// course number
		getline(dataStream, temp, ',');
		courseNum = stoi(temp);
		// course name
        getline(dataStream, courseName, ',');
        // professor ID
        getline(dataStream, profID, ',');
        // professor first name
        getline(dataStream, profFirst, ',');
        // professor last name
        getline(dataStream, profLast, ',');

        // adds new instance of professor to BST
        profDb.addProfessor(profID, profFirst + " " + profLast);
        Professor* np = profDb.searchProfessor(profID);
        
        // adds new instance of course
        Course *nc = new Course;
        nc->year = year;
        nc->department = department;
        nc->courseNum = courseNum;
        nc->courseName = courseName;
        nc->prof = np;
        np->coursesTaught.push_back(nc);

        // check for collision
        if(hashTable[hash(courseNum)]){ 
            colCount++; // increment collision counter
            Course* curr = hashTable[hash(courseNum)];
            searchCount++; // increment search counter
            while(curr->next){
                curr = curr->next;
                searchCount++; // increment search counter
            }
            curr->next = nc;
            nc->previous = curr;
        }else{
            hashTable[hash(courseNum)] = nc;
        }
	}
    dataFile.close();
    // outputs seach and collision count for file
    cout << "[CHAINING] Hash table populated" << endl;
    cout << "--------------------------------------------------------" << endl;
    cout << "Collisions using chaining: " << colCount << endl;
    cout << "Search operations using chaining: " << searchCount << endl << endl;
}

/**
* search - finds a course and calls displayCourseInfo for the course
*
* @param courseYear, courseNumber, profId 
* @return -
*/

void HashChaining::search(int courseYear, int courseNumber, string profId)
{
    int searchCount = 0;
    bool done = false;
    Course* curr = hashTable[hash(courseNumber)];
    cout << "[CHAINING] Search for a course" << endl << "-------------------------------------" << endl;
    if(curr->prof->profId == profId && curr->year == courseYear){
        cout << "Search operations using chaining: " << searchCount << endl;
        displayCourseInfo(curr);
        done = true;
    }
    while(curr->next && done == false){
        curr = curr->next;
        searchCount++;
        if(curr->prof->profId == profId && curr->year == courseYear){
            cout << "Search operations using chaining: " << searchCount << endl;
            displayCourseInfo(curr);
            done = true;
        }
    }
    if(done == false){
        displayCourseInfo(nullptr);
    }
}

/**
* displayAllCourses - calls displayCourseInfo for each course in hash table
*
* @param -
* @return -
*/

void HashChaining::displayAllCourses()
{
    cout << "[CHAINING] displayAllCourses()" << endl << "-------------------------------------" << endl;
    for(int i = 0; i < hashTableSize; i++){
        if(hashTable[i]){
            Course *c = hashTable[i];
            displayCourseInfo(c);
            while(c->next){
                c = c->next;
                displayCourseInfo(c);
            }
        }
    }
}

/**
* displayCourseInfo - outputs course year, name, number, and professor for input course
*
* @param c
* @return -
*/

void HashChaining::displayCourseInfo(Course* c)
{
	if(c){
        cout << c->year << " " << c->courseName << " " << c->courseNum << " " << c->prof->profName << endl << endl;
    }else{
        cout << "Course not found" << endl << endl;
    }
}