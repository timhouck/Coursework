//-----------------------------------------------------------------------------
// CSCI2270 Course Project
//
// Identification: HashOpenAddressing.cpp
//-----------------------------------------------------------------------------

#include "HashOpenAddressing.h"

using namespace std;

/**
* HashChaining - constructor for HashChaining
* 
* @param size
* @return -
*/

HashOpenAddressing::HashOpenAddressing(int size)
{
    hashTableSize = size;
    hashTable = new Course*[hashTableSize];
    for(int i=0;i<size;i++)
        hashTable[i] = nullptr;
}

/**
* ~HashChaining - destructor for HashChaining
* 
* @param -
* @return -
*/

HashOpenAddressing::~HashOpenAddressing()
{
    for(int i=0;i<hashTableSize;i++)
        hashTable[i] = nullptr;
    delete hashTable;
}

/**
* hash - calculates the hash of a key
* 
* @param courseNumber
* @return int
*/

int HashOpenAddressing::hash(int courseNumber)
{
    return courseNumber % hashTableSize;
}

/**
* bulkInsert - inserts all courses in a file to hash table using
* chaining while adding each new professor to a BST 
*
* @param filename
* @return -
*/

void HashOpenAddressing::bulkInsert(string filename)
{
    int colCount = 0;
    int searchCount = 0;
    ifstream dataFile;
	string dataLine;
    dataFile.open(filename);
    getline(dataFile, dataLine); //discard example line
    while (getline(dataFile, dataLine))
	{
        int year;
        string department;
        int courseNum;
        string courseName;
        string profID;
        string profFirst;
        string profLast;
        string temp;

		stringstream dataStream(dataLine);

        // year
		getline(dataStream, temp, ',');
        year = stoi(temp);
        // department
		getline(dataStream, department, ',');
		// course number
		getline(dataStream, temp, ',');
		courseNum = stoi(temp);
		// course name
        getline(dataStream, courseName, ',');
        // professor ID
        getline(dataStream, profID, ',');
        // professor first name
        getline(dataStream, profFirst, ',');
        // professor last name
        getline(dataStream, profLast, ',');

        // adds new instance of professor to BST
        profDb.addProfessor(profID, profFirst + " " + profLast);
        Professor* np = profDb.searchProfessor(profID);

        // adds new instance of course
        Course *nc = new Course;
        nc->year = year;
        nc->department = department;
        nc->courseNum = courseNum;
        nc->courseName = courseName;
        nc->prof = np;
        np->coursesTaught.push_back(nc);

        // check for collision
        if(hashTable[hash(courseNum)]){
            colCount++; // increment collision counter
            // quadratic probing
            int num = courseNum;
            for(int i = 1; i < hashTableSize; i++){
                searchCount++; // increment search counter
                num = num + i*i;
                if(!hashTable[hash(num)]){
                    hashTable[hash(num)] = nc;
                    i = hashTableSize;
                }
            }
        }else{
            hashTable[hash(courseNum)] = nc;
        }
	}
    dataFile.close();
    // outputs seach and collision count for file
    cout << "[OPEN ADDRESSING] Hash table populated" << endl;
    cout << "--------------------------------------------------------" << endl;
    cout << "Collisions using open addressing: " << colCount << endl;
    cout << "Search operations using open addressing: " << searchCount << endl << endl;
}

/**
* search - finds a course and calls displayCourseInfo for the course
*
* @param courseYear, courseNumber, profId 
* @return -
*/


void HashOpenAddressing::search(int courseYear, int courseNumber, string profId)
{
    int searchCount = -1;
    bool done = false;
    int num = courseNumber;
    cout << "[OPEN ADDRESSING] Search for a course" << endl << "-------------------------------------" << endl;
    // loops through each hash table element until course is found
    for(int i = 0; i < hashTableSize; i++){
        searchCount++; // incremetns search counter
        num = num + i*i; //quadratic probing
        if(hashTable[hash(num)]){
            if(hashTable[hash(num)]->prof->profId == profId && hashTable[hash(num)]->year == courseYear){
                cout << "Search operations using open addressing: " << searchCount << endl; // outputs number of searches until found
                displayCourseInfo(hashTable[hash(num)]);
                done = true;
                i = hashTableSize;
            }
        }
    }
    if(done == false){
        displayCourseInfo(nullptr);
    }
}

/**
* displayAllCourses - calls displayCourseInfo for each course in hash table
*
* @param -
* @return -
*/

void HashOpenAddressing::displayAllCourses()
{
    cout << "[OPEN ADDRESSING] displayAllCourses()" << endl << "-------------------------------------" << endl;
    // loops through each hash table element and calls displayCourseInfo
    for(int i = 0; i < hashTableSize; i++){
        if(hashTable[i]){
            Course *c = hashTable[i];
            displayCourseInfo(c);
        }
    }
}

/**
* displayCourseInfo - outputs course year, name, number, and professor for input course
*
* @param c
* @return -
*/

void HashOpenAddressing::displayCourseInfo(Course* c)
{
	if(c){ // if course was found
        // outputs course info
        cout << c->year << " " << c->courseName << " " << c->courseNum << " " << c->prof->profName << endl << endl;
    }else{
        cout << "Course not found" << endl << endl;
    }
}