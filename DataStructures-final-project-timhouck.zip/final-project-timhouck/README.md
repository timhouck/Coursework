1. Does one hashing collision resolution work better than the other? Consider the datasets we used and a much larger dataset with 1 million records.Explain your answer.

Chaining led to lower collisions and search operations in each test file, so it is the better collision resolution in this case. Chaining would also be better if we had a much larger dataset. One reason for this is that open addressing can only store as many elements as the size of the table, while chaining table's size only must be the amount of unique elements in the dataset. This leads to simplicity as well as lower search counts.

2. We used the same BST for both hashing mechanisms. What alternative data structure would you advise? Why?

I would use a Red-Black Tree. This would keep many of the same properties as the BST while allowing the tree to be self-balancing. Because of this, the tree would be easier to traverse and would be more efficient when searching for a professor.

3. Explain a few ways you could improve the application.

I would imporve this application by adding or altering options within the main menu. For example a student could search for a course in a specific year and see all professors that taught that course so the student could decide which professor to take the course with. One could also use the BST to search for courses taught by a professor above or below a certain course number so students can search for upper or lower level courses more easily. I would also add a graph or series of graphs ordered by prerequisites so a student could see every course they must take before their desired course.
